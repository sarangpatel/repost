<?php
class Model{
     private $conn;

     // constructor with $db as database connection
    public function __construct($db){
        $this->conn = $db;
    }


	public function checkLogin($username, $password){
        $query = "SELECT dcCompanyName dcSurname, dcName, dcNotifyEmail, dcUserName, dcPassword, " .
                "dcDefaultLanguage, dcUser, dcType FROM tb_users WHERE isActive = 1 and " .
                "dcUserName ='$username'and dcPassword = '$password' LIMIT 1";
        // prepare query statement
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        $num = $stmt->rowCount();
        $data = array();
        if($num > 0){
            $data = $stmt->fetchAll();
        }
        return $data;
    }

	public function getUserAnalytics($idUser){

		$orderAssignedToday = 0;
		$allOrdersToday = 0;
		$allLastWeekOrders = 0;
		$allLastMonthOrders = 0;

		//order assigned today
		$query = "SELECT count(1) as order_assigned_count FROM tb_orders WHERE tb_orders.dcUserDelivery='$idUser'  
				 and iCurrentState = 2 and `ddDeliveryDate` = CURDATE()";
		$stmt = $this->conn->prepare($query);
		$stmt->execute();
		if($stmt->rowCount() > 0){
			$orderAssigned = $stmt->fetch();
			$orderAssigned = $orderAssigned['order_assigned_count'];
		}

		//today all orders
		$query = "SELECT count(1) as all_orders_count FROM tb_orders WHERE tb_orders.dcUserDelivery='$idUser'  
				and iCurrentState in (2,3,4) and `ddDeliveryDate` = CURDATE()";
		$stmt = $this->conn->prepare($query);
		$stmt->execute();

		if($stmt->rowCount() > 0){
			$allOrdersToday = $stmt->fetch();
			$allOrdersToday = $allOrdersToday['all_orders_count'];
		}

		//LAST WEEK ORDERS
		$query = "SELECT count(1) as lask_week_orders_count FROM tb_orders WHERE tb_orders.dcUserDelivery='$idUser'
			 and iCurrentState in (2,3,4) and  `ddDeliveryDate` >= DATE_SUB(CURDATE(),INTERVAL 7 DAY)";

		$stmt = $this->conn->prepare($query);
		$stmt->execute();

		if($stmt->rowCount() > 0){
			$allLastWeekOrders = $stmt->fetch();
			$allLastWeekOrders = $allLastWeekOrders['lask_week_orders_count'];
		}

		//LAST MONTH ORDERS
		$query = "SELECT count(1) as last_month_orders FROM tb_orders WHERE tb_orders.dcUserDelivery='$idUser'
			 and iCurrentState in (2,3,4) and `ddDeliveryDate` >= DATE_SUB(CURDATE(),INTERVAL 30 DAY)";

		$stmt = $this->conn->prepare($query);
		$stmt->execute();

		if($stmt->rowCount() > 0){
			$allLastMonthOrders = $stmt->fetch();
			$allLastMonthOrders = $allLastMonthOrders['last_month_orders'];
		}	
		return array('assigned_order' => $orderAssigned, 'total_orders_today' => $allOrdersToday,
				'total_orders_lastweek' => $allLastWeekOrders, 'total_orders_lastmonth' => $allLastMonthOrders );
	}


	
	

	public function getUserCredantials($email){
		$query = "SELECT `dcUserName`,`dcPassword`,`dcNotifyEmail` FROM `tb_users` WHERE `dcNotifyEmail` = '$email'" ;
				
		$stmt = $this->conn->prepare($query);
		$stmt->execute();
		$num = $stmt->rowCount();
		$data = array();
		if($num > 0){
			$data = $stmt->fetch();
		}
		return $data;
	}


	public function getUserCurrentBalance($idUser, $idMonth, $idYear){
		$query = 'SELECT *
		FROM   (SELECT `ddtimestamp`                    AS DataMov,
					   Concat("order sent #", dcorderint, "(", dcorderext, ")", " / ",
					   dcrecipientcity
					   , "(", dcrecipientcountry, ")") AS Description,
					   dmpropbudget                     AS Received,
					   0                                AS Sent
				FROM   tb_orders
				WHERE  Year(ddtimestamp) = '.$idYear.'
					   AND Month(ddtimestamp) = '.$idMonth.'
					   AND icurrentstate IN ( 2, 3, 4, 5 )
					   AND dcuserowner = '.$idUser.'
				UNION
				SELECT Tab_B.timest             AS DataMov,
					   Concat("order received #", tb_orders.dcorderint, " / ",
					   dcrecipientcity,
					   "(",
					   dcrecipientcountry, ")") AS Description,
					   0                        AS Received,
					   dmcost                   AS Sent
				FROM   tb_orders,
					   (SELECT dcorderid,
							   Max(ddtimestamp) AS TimeST
						FROM   tb_orderhistory
						WHERE  istate = 2
						GROUP  BY dcorderid) AS Tab_B
				WHERE  tb_orders.dcorderint = Tab_B.dcorderid
					   AND Year(Tab_B.timest) = '.$idYear.'
					   AND Month(Tab_B.timest) = '.$idMonth.'
					   AND icurrentstate IN ( 2, 3, 4, 5 )
					   AND dcuserdelivery = '.$idUser.'
				UNION
				SELECT dddata     AS DataMov,
					   dcdescription,
					   0          AS Received,
					   `dmamount` AS Sent
				FROM   tbMovements
				WHERE  Year(dddata) = '.$idYear.'
					   AND Month(dddata) = '.$idMonth.'
					   AND dcuser = '.$idUser.'
					   AND dctype = 0
				UNION
				SELECT dddata     AS DataMov,
					   dcdescription,
					   `dmamount` AS Received,
					   0          AS Sent
				FROM   tbMovements
				WHERE  Year(dddata) = '.$idYear.'
					   AND Month(dddata) = '.$idMonth.'
					   AND dcuser = '.$idUser.'
					   AND dctype = 1) AS TabellaAggregata
				ORDER  BY datamov';

				$stmt = $this->conn->prepare($query);
				$stmt->execute();
				$num = $stmt->rowCount();
				$data = array('balance' => 0);
				if($num > 0){
					$records = $stmt->fetchAll();
					$received = 0;
					$sent = 0;
					foreach($records as $d){
						$received += $d['Received'];
						$sent += $d['Sent'];
					}
					$data['balance'] = $received - $sent;
				}
				return $data;
		}

		public function getOrderDetailsbyUser($orderid, $userid){
			$query = "SELECT dcorderint,
				   dcorderext,
				   ddtimestamp,
				   dcproductdescription,
				   dctyperequest,
				   dmpropbudget,
				   dmcost,
				   dcrecipientname,
				   dcrecipientaddress,
				   dcrecipientcity,
				   dcrecipientzipcode,
				   dcrecipientcountry,
				   dcrecipientphone,
				   dcsendername,
				   dcmessagecard,
				   dcsenderemail,
				   dcnotes,
				   dcorderchannel,
				   icurrentstate,
				   dcuserowner,
				   dcuserdelivery,
				   dddeliverydate,
				   dcurlimage,
				   ireportingtype,
				   dmfees,
				   dcinternalnotes,
				   tb_orderstate.dcnameeng,
				   tb_orderstate.dcnameita
			FROM   tb_orders,
				   tb_orderstate
			WHERE  tb_orders. icurrentstate = tb_orderstate.iState
				   AND dcorderint = $orderid
				   AND dcuserdelivery = $userid"; 
 				$stmt = $this->conn->prepare($query);
				$stmt->execute();
				$num = $stmt->rowCount();
				$data = array();
				if($num > 0){
					$data = $stmt->fetchAll();
				}
				return $data;

		}

		public function getOrdersbyUser($userid, $orderstatus='', $deliveryfrom = '', $deliveryto = '', $recname='', $recaddr='', $searchcond = ''){
			$cond = '';
			if($orderstatus != ''){
				$cond .= " and tb_orders.iCurrentState = '$orderstatus' ";
			}
			if($deliveryfrom != '' && $deliveryto != '' ){
				$cond .= " and tb_orders.ddDeliveryDate between '$deliveryfrom' and '$deliveryto' ";
			}
			if($recname != ''){
				$cond .= " and tb_orders.dcRecipientName like '%$recname%' ";
			}
			if($recaddr != ''){
				$cond .= " and tb_orders.dcRecipientAddress like '%$recaddr%' ";
			}

			if($searchcond != ''){
				$cond .= " and (CONCAT(tb_orders.dcOrderInt, ' ', tb_orders.dcRecipientName, ' ',  tb_orders.dcRecipientCity, ' ', tb_orders.dcRecipientAddress))  LIKE ('%$searchcond%') ";

			}

			$query =   "SELECT  tb_orders .*, tb_orderstate.dcNameEng, tb_orderstate.dcNameIta FROM tb_orders, tb_orderstate WHERE " .
						" tb_orders.iCurrentState= tb_orderstate.iState and tb_orders.dcUserDelivery = $userid " .  $cond . 
						"  order by dcOrderInt desc limit 500" ;
						
			$stmt = $this->conn->prepare($query);
			$stmt->execute();
			$num = $stmt->rowCount();
			$data = array();
			if($num > 0){
				$data = $stmt->fetchAll();
			}
			return $data;
		}

		/* OLD: 1Feb 2022
		public function getOrderCommunicationByOrderID($order_id,$user_id){
			//$query = "select timestamp,  messageText from tbMessagesBoard where orderID='". $order_id . "' and typeRequest = 'I-B' order by timestamp limit 200" ;
		
			$query = 
			"select timestamp,  messageText, dcUserDelivery from tbMessagesBoard, tb_orders where tbMessagesBoard.orderID = tb_orders.dcOrderInt
			 AND tbMessagesBoard.orderID='". $order_id . "' and typeRequest = 'I-B' AND dcUserDelivery = " . $user_id . " order by timestamp limit 800";

			$stmt = $this->conn->prepare($query);
			$stmt->execute();
			$num = $stmt->rowCount();
			$data = array();
			if($num > 0){
				$data = $stmt->fetchAll();
			}
			return $data;
		}*/


	
		public function getOrderCommunicationByOrderID($order_id,$user_id){
			//$query = "select timestamp,  messageText from tbMessagesBoard where orderID='". $order_id . "' and typeRequest = 'I-B' order by timestamp limit 200" ;
			$query = 
			"select timestamp,  messageText, dcUserDelivery, typeRequest from tbMessagesBoard, tb_orders where tbMessagesBoard.orderID = tb_orders.dcOrderInt
			 AND tbMessagesBoard.orderID='". $order_id . "' and typeRequest in ('I-B','F-W') AND dcUserDelivery = " . $user_id . " order by timestamp limit 100";

			$stmt = $this->conn->prepare($query);
			$stmt->execute();
			$num = $stmt->rowCount();
			$data = array();
			if($num > 0){
				$data = $stmt->fetchAll();
			}
			return $data;
		}
	



		public function sendCommunicationIssue($order_id, $user_id, $text){
			$to = TO_EMAIL;
			$subject = COMMUNICATION_ISSUE_SUBJECT . ': ' . $order_id;
			$query = "INSERT INTO `tbMessagesBoard` (`idMessage`, `timestamp`, `typeRequest`, `orderID`, `email`, `messageText`, `name`, `phone`, 
			`companyname`, `NumEmail`, `direction`) VALUES 
			(NULL, CURRENT_TIMESTAMP, 'F-W', ? , 'club@wineflowers.com', ? , '', '', '', '0', '1');";
			$stmt = $this->conn->prepare($query);
			$stmt->execute([$order_id, $text]);

			$message = "
			<html>
			<head>
			<title>Order ISSUE</title>
			</head>
			<body>
			<p>Dear Admin,</p>
			<br /><b>Communication text:</b><br /><br />" . $text .  "<br /><br />Thanks,<br />". EMAIL_SIGNATURE . "</body></html>";
			// Always set content-type when sending HTML email

			$headers  = "From: " . FROM_EMAIL . "\r\n";
    		$headers .= "Reply-To: " . FROM_EMAIL . "\r\n";
			$headers .= "MIME-Version: 1.0" . "\r\n";
			$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";

			// More headers
			//$headers .= 'From: <webmaster@example.com>' . "\r\n";
			//$headers .= 'Cc: myboss@example.com' . "\r\n";

			mail($to,$subject,$message,$headers);
			return array();
		}


		
		public function setPicturebyOrder($order_id, $user_id, $notes, $file){
			$to = TO_EMAIL;
			$subject = COMMUNICATION_ISSUE_SUBJECT . ': ' . $order_id;
			
			$ext = pathinfo($file['file']['name'], PATHINFO_EXTENSION);

			$application_id = 9999;
			$curl = curl_init();
			curl_setopt_array($curl, array(
				CURLOPT_URL => UPLOAD_SERVICE,
				CURLOPT_RETURNTRANSFER => true,
				CURLOPT_ENCODING => '',
				CURLOPT_MAXREDIRS => 10,
				CURLOPT_TIMEOUT => 0,
				CURLOPT_FOLLOWLOCATION => true,
				CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
				CURLOPT_CUSTOMREQUEST => 'POST',
				CURLOPT_POSTFIELDS => array('file'=> new CURLFILE($file['file']['tmp_name']), 'ext' =>  $ext,
					'order_id' => $order_id, 'user_id' => $user_id,'notes' =>  $notes, 'application_id' => $application_id),
			));

			$response = json_decode(curl_exec($curl),true);
			if($response['error']){
				return array('error' => true, 'msg' => 'Error in uploading file. Please try again.');
			}else{
	
				
				$message = "
				<html>
				<head>
				<title>Order ISSUE</title>
				</head>
				<body>
				<p>Dear Admin,</p>
				<br /><b>Picture Scope:</b><br /><br />" . $notes .  "<br /><br />Thanks,<br />". EMAIL_SIGNATURE . "</body></html>";

				$headers  = "From: " . FROM_EMAIL . "\r\n";
				$headers .= "Reply-To: " . FROM_EMAIL . "\r\n";
				$headers .= "MIME-Version: 1.0" . "\r\n";
				$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";

				// More headers
				//$headers .= 'From: <webmaster@example.com>' . "\r\n";
				//$headers .= 'Cc: myboss@example.com' . "\r\n";

				mail($to,$subject,$message,$headers);
				return array('error' => false, 'msg' => 'File uploaded and mail sent to admin.', 'file_path' => $response['data'][0]['uploaded_file']);
			}

		}


		public function setOrderStatus($order_id, $user_id, $order_status){
			if($order_status == '99'){

				$to = TO_EMAIL;
				$message = "
				<html>
				<head>
				<title>Order Declined</title>
				</head>
				<body>
				<p>Dear Admin,</p>
				<br /><b>Order ID: $order_id </b> has been declined by Florist.<br />" .  "<br /><br />Thanks,<br />". EMAIL_SIGNATURE . "</body></html>";
				// Always set content-type when sending HTML email
	
				$headers  = "From: " . FROM_EMAIL . "\r\n";
				$headers .= "Reply-To: " . FROM_EMAIL . "\r\n";
				$headers .= "MIME-Version: 1.0" . "\r\n";
				$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
	
				// More headers
				//$headers .= 'From: <webmaster@example.com>' . "\r\n";
				//$headers .= 'Cc: myboss@example.com' . "\r\n";
				$subject = "$order_id has been DECLINED.";
				mail($to,$subject,$message,$headers);
	

			}else{
				$query = "update tb_orders set iCurrentState = '$order_status' where dcOrderInt = $order_id and dcUserDelivery = '$user_id' " ;
				$stmt = $this->conn->prepare($query);
				$stmt->execute();
			}
			return array();
		}

	
		function writeAccountingJournal($id, $data_mov, $descrizione, $importo, $tipocontabile, $note)
		{
			
			$query = "select count(*) as isAcc from tbGiornaleContabile WHERE dcOrderInt=$id";

			$stmt = $this->conn->prepare($query);
			$stmt->execute();
			$num = $stmt->rowCount();

			$tipoScrittura = "NuovaRiga";
			if($num > 0){
				$data = $stmt->fetch();
				if($data['isAcc'] > 0){
					$tipoScrittura = "AggiornaRiga"; //update row
				}else{ 
					$tipoScrittura = "NuovaRiga"; //new row
				}
			}
			if($tipoScrittura == "NuovaRiga"){
			
				$query = "INSERT INTO tbGiornaleContabile (dcOrderInt, data_mov, descrizione, importo, idTipoContabile, note) VALUES 
				(" . $id . ", FROM_UNIXTIME(" . strtotime($data_mov) . "), ?, ?, ?, ? )";
			
			}else if ($tipoScrittura == "AggiornaRiga"){

				$query = "UPDATE tbGiornaleContabile SET descrizione = ?, importo = ?, idTipoContabile = ?, note = ?  WHERE dcOrderInt=" . $id;
			}
			$stmt = $this->conn->prepare($query);
			$stmt->execute([ $descrizione, $importo, $tipoScrittura, $note ]);
			return true;

		}



		function notifyDelivered($id)
		{

			$query = "SELECT dcOrderInt, dcOrderExt, ddDeliveryDate, dcUserOwner, dcSenderEMail,dcRecipientName,  
			 dmPropBudget, dmCost, dmFEEs  FROM tb_orders WHERE dcOrderInt = '$id' ";

				
			$stmt = $this->conn->prepare($query);
			$stmt->execute();
			$num = $stmt->rowCount();
			$orderdeli = $stmt->fetch();

			$ACCOUNTINGVALUE = $orderdeli['dmPropBudget'] - $orderdeli['dmCost'] - $orderdeli['dmFEEs'];

			writeAccountingJournal($id, $orderdeli['ddDeliveryDate'], "Consegna Ordine" , $ACCOUNTINGVALUE, 1, "");

			$from = 'club@wineflowers.com';

			$headers  = "From: " . $from . "\r\n";
			$headers .= "Reply-To: " . $from . "\r\n";
			$headers .= "MIME-Version: 1.0" . "\r\n";
			$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";

			////$_POST["dcOrderInt"].', '.$_POST['dcRecipientCity'].', '.$_POST['dcRecipientCountry'].', '.$_POST['dcRecipientName'].', '.$_POST['ddDeliveryDate'];
			$subject = 'Order #'.  $id . ' changed status: DELIVERED! - Wineflowers.com';
			$message = '<font face="Courier" size="3">Dear Partner, <br />
			we are pleased to confirm that Your order ';
			
			if($orderdeli['dcOrderExt'] != '' && $orderdeli['dcOrderExt'] != 'NULL' && $orderdeli['dcOrderExt'] != NULL) 
			$message.='('.$orderdeli['dcOrderExt'].'/'.$orderdeli['dcRecipientName'].') ';

			$message .= 'has <br>been correctly delivered on requested date (<b>'.date("d-m-Y",strtotime($orderdeli['ddDeliveryDate'])).'</b>).<br><br>

			<b>For any issue relating this order, email us at <a href ="mailto:corporate@wineflowers.com?subject=ISSUE - '.$subject.'">corporate@wineflowers.com just clicking here!</a></b><br><br>

			<br>To view order details, log in to: <a href="https://club.wineflowers.com/">Wineflowers.com Club</a><br>
			
			Kindly Regards,<br><br>
			<b>Wineflowers.com Group</b><br>
			<i>International Flowers & Gifts Delivery</i><br><br>';

			$query = 'SELECT dcUser, dcUserName, dcEmail, dcNotifyEmail FROM tb_users WHERE dcUser="' . $orderdeli['dcUserOwner'] . '"';
			$stmt = $this->conn->prepare($query);
			$stmt->execute();
			$user_mail = $stmt->fetch();

			if($user_mail['dcNotifyEmail'] == '' || $user_mail['dcNotifyEmail'] == NULL || $user_mail['dcNotifyEmail'] == 'NULL') 
				$to_mail = $user_mail['dcEmail'];
			else 
			 $to_mail = $user_mail['dcNotifyEmail'];
			
			$to = $to_mail;

			// send mail to partner
			//mail($to,$subject,$message,$headers);
			createEmail($subject,$message,$to);

			// send mail to club
			//mail("club@wineflowers.com",$subject,$message,$headers);
			createEmail($subject,$message,"club@wineflowers.com");

			if($orderdeli['dcSenderEMail']!='' && $orderdeli['dcSenderEMail']!='NULL' && $orderdeli['dcSenderEMail']!=NULL)
			{
				// Setting Lingua del Cliente
				$getCustomerLanguage =  get_CustomerLanguage($id);
				
				if ($getCustomerLanguage == "ITA")
				{
					$message = '<font face="Courier" size="3">Gentile Cliente, <br>
					siamo lieti di informarla che il suo ordine ';
					if($orderdeli['dcOrderExt'] !='' && $orderdeli['dcOrderExt'] != 'NULL' && $orderdeli['dcOrderExt'] != NULL)
					$message.='('.$orderdeli['dcOrderExt'].'/'.$orderdeli['dcRecipientName'].') ';

					$message .= ' e\' stato correttamente consegnato nella data richiesta (<b>'.$orderdeli['ddDeliveryDate'].'</b>).<br><br>

					<b>Per qualsiasi problema relativo all\'ordine, la preghiamo di contattarci via email <a href ="mailto:customer-care@wineflowers.com?subject=ISSUE - Order #'.$orderdeli['dcOrderExt'].'">customer-care@wineflowers.com semplicemente cliccando qui!</a></b><br><br>

					Ci farebbe piacere inoltre ricevere un suo parere circa il nostro servizio, se desidera potra\' farlo <a href="https://www.wineflowers.com/trackingorder.php?TKLG=ITA&orderID='.$orderdeli['dcOrderExt'].'&emailID='.$orderdeli['dcSenderEMail'].'&esito=order_found">cliccando qui</a>.<br/><br/> 	

					Come ringraziamento per averci scelto, le offriamo uno <b>sconto del 10%</b> sui suoi futuri acquisti utilizzando il codice coupon <b>W-CUSTDISC10</b> in fase di inserimento ordine.<br><br>
					
					Cordiali Saluti,<br><br>

					<b>Wineflowers.com Group</b><br>
					<i>International Flowers & Gifts Delivery</i><br><br>

					Skype me: wine.flowers - Fax: +39 0833 1982905<br>
					<a href="https://www.facebook.com/consegnafiori">Share us on Facebook</a> - <a href="https://twitter.com/wineflowers">Follow us on Twitter</a> - Blog: <a href="https://www.wineflowers.com/blog/">www.wineflowers.com/blog/</a><br>';

					//$_POST["dcOrderInt"].', '.$_POST['dcRecipientCity'].', '.$_POST['dcRecipientCountry'].', '.$_POST['dcRecipientName'].', '.$_POST['ddDeliveryDate'];

					$subject = 'Ordine CONSEGNATO! - Wineflowers.com';

				}else{

					$message = '<font face="Courier" size="3">Dear Customer, <br>
					we are pleased to confirm that Your order ';
					
					if($orderdeli['dcOrderExt'] != '' && $orderdeli['dcOrderExt'] != 'NULL' && $orderdeli['dcOrderExt'] != NULL)
					$message.='('.$orderdeli['dcOrderExt'].'/'.$orderdeli['dcRecipientName'].') ';

					$message .= ' has <br>been correctly delivered on requested date (<b>'.$orderdeli['ddDeliveryDate'].'</b>).<br><br>

					<b>For any issue relating this order, email us at <a href ="mailto:customer-care@wineflowers.com?subject=ISSUE - Order #'.$orderdeli['dcOrderExt'].'">customer-care@wineflowers.com just clicking here!</a></b><br><br>

					We would like to receive your opinion regarding our service, please leave us a comment <a href="https://www.wineflowers.com/trackingorder.php?TKLG=ENG&orderID='.$orderdeli['dcOrderExt'].'&emailID='.$orderdeli['dcSenderEMail'].'&esito=order_found">clicking here</a>.<br/><br/> 	


					As a thank you for your shopping with us, we offer you a <b>10% discount</b> for your next purchases. You simply need to enter this code <b>W-CUSTDISC10</b> the next time during the payment process. This discount code is valid several times.<br><br>
					
					Kindly Regards,<br><br>

					<b>Wineflowers.com Group</b><br>
					<i>International Flowers & Gifts Delivery</i><br><br>

					Skype me: wine.flowers - Fax: +39 0833 1982905<br>
					<a href="https://www.facebook.com/consegnafiori">Share us on Facebook</a> - <a href="https://twitter.com/wineflowers">Follow us on Twitter</a> - Blog: <a href="https://www.wineflowers.com/blog/">www.wineflowers.com/blog/</a><br>';

					//$_POST["dcOrderInt"].', '.$_POST['dcRecipientCity'].', '.$_POST['dcRecipientCountry'].', '.$_POST['dcRecipientName'].', '.$_POST['ddDeliveryDate'];

					$subject = 'Order DELIVERED! - Wineflowers.com';

				}
				$to = $orderdeli['dcSenderEMail'];
				// send mail to customer

				//mail($to,$subject,$message,$headers);
				createEmailCustomerCare($subject,$message,$to);

				//Notify incoincing request, if it is needed
				notifyToBeInvoiced($id);

			}//if dcSendEmail

		}//end function








		

















		//not using
		function uploadFile($file){
			$ext = pathinfo($file['name'], PATHINFO_EXTENSION);
			$token = md5(uniqid(rand(), true));
			/* if (in_array($ext, array('png','gif','jpeg','jpg','bmp'))) {
				$document_type = 'images';
				$upload_path = IMAGES_DIR_PATH;
				$upload_url = IMAGES_HTTP_PATH;
			} */
			$upload_path = IMAGES_DIR_PATH;
			$upload_url = IMAGES_HTTP_PATH;

			$upload_path = $upload_path .  $token . '.' . $ext;
			if(move_uploaded_file($file['tmp_name'], $upload_path)) {
				$upload_path = $upload_url . $token . '.' . $ext;
				return array('error' => false, 'msg' => 'uploaded', 'file_path' => $upload_path);
			}else{
				return array('error' => true, 'msg' => 'Error in moving file. Please try again.');
			}
		}


}

?>
