<?php
  
// get database connection
include_once './config/core.php';
include_once './config/database.php';
include_once './config/model.php';

$database = new Database();
$db = $database->getConnection();

$model = new Model($db);

$postedData = json_decode(file_get_contents("php://input"), true);

$order_id       = $postedData['order_id'];

if(!empty($order_id)){

    $result = $model->notifyDelivered($order_id);
    $returnData['error'] = false;
    $returnData['msg'] = "success";
    http_response_code(200);
    echo sendResponse($returnData);

}else{

    $returnData['error'] = true;
    $returnData['msg'] = "order_id is required";
    $returnData['data'] = null;
    http_response_code(400);
    echo sendResponse($returnData);

}

  
?>