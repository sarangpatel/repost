<?php
  
// get database connection
include_once './config/core.php';
include_once './config/database.php';
include_once './config/model.php';

$database = new Database();
$db = $database->getConnection();

$model = new Model($db);

$postedData = json_decode(file_get_contents("php://input"), true);

$order_id       = $postedData['order_id'];
$date_mov       = $postedData['date_mov'];
$description    = $postedData['description'];
$amt            = $postedData['amt'];
$type           = $postedData['type'];
$notes          = !empty($postedData['notes']) ? $postedData['notes'] : '' ;

/* {
    "order_id" : 2998,
  "date_mov": "2022-11-11 11:22:22",
  "description" : "descriptin",
    "amt" : "120.22",
  "type": "NuovaRiga",
  "notes": "XX"
}
 */

if(!empty($order_id) && !empty($date_mov) && !empty($description) && !empty($amt) && !empty($type)){

    if((bool)strtotime($date_mov)){

        $result = $model->writeAccountingJournal($order_id, $date_mov, $description, $amt, $type, $notes);
        $returnData['error'] = false;
        $returnData['msg'] = "success";
        http_response_code(200);
        echo sendResponse($returnData);
    }else{
        $returnData['error'] = true;
        $returnData['msg'] = "date_move - YYYY-MM-DD HH:mm:ss format is required";
        $returnData['data'] = null;
        http_response_code(400);
        echo sendResponse($returnData);
    
    }

}else{

    $returnData['error'] = true;
    $returnData['msg'] = "order_id/date_move ( YYYY-MM-DD HH:mm:ss)/description/amt/type is required";
    $returnData['data'] = null;
    http_response_code(400);
    echo sendResponse($returnData);

}

  
?>